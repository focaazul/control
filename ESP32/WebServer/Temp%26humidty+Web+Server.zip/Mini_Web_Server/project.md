Mini Web Server
===============

This example implements a very minimal web server by opening a TCP socket
in listening mode, reading HTTP headers and sending out some HTML.

It prints the IP to connect to in the serial console. Type it in your browser
and test your mini web server!

It uses the CC3000 wireless driver, however any network driver can be used
changing only a few lines of code.


